class Script < ActiveRecord::Base
end

# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
ShowtermIo::Application.config.secret_token = '2e4906ab32550d195da35c32ff0280ec1f1a8d571d8365f8ec3a869e42fe5e67284db640f38bfcdcb0652a00fce4c3694514ef4438387ae1d7a32e63b216a76f'
